import { default as redirectUrlComposer_1_0 } from './redirect-url-composer/1.0';

const fn = {
  "redirectUrlComposer 1.0": redirectUrlComposer_1_0,
};

export default fn;
